// Intersection Observer for fade-up animations
const fadeEls = document.querySelectorAll('.fade-up');

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

fadeEls.forEach(el => observer.observe(el));

// Trigger hero elements immediately
document.querySelectorAll('#hero .fade-up').forEach((el, i) => {
  setTimeout(() => el.classList.add('visible'), 100 + i * 150);
});

// Mobile menu
const hamburger = document.getElementById('hamburger');
const mobileMenu = document.getElementById('mobileMenu');

hamburger.addEventListener('click', () => {
  mobileMenu.classList.toggle('open');
});

function closeMobile() {
  mobileMenu.classList.remove('open');
}

// Nav background on scroll
const nav = document.querySelector('nav');
window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    nav.style.background = 'rgba(19,15,14,0.95)';
  } else {
    nav.style.background = 'rgba(19,15,14,0.75)';
  }
});

// Inquiry form — email capture + submission
const form = document.getElementById('inquiryForm');
const emailInput = document.getElementById('emailInput');
const formSuccess = document.getElementById('formSuccess');

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = emailInput.value.trim();
  const submitBtn = form.querySelector('.form-submit');
  submitBtn.textContent = 'Sending…';
  submitBtn.disabled = true;

  try {
    await fetch('https://buildpad.io/api/website/dc0d6192-3ee4-4ef9-919f-cbbda01f5fb8/capture-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
  } catch (_) {}

  form.style.display = 'none';
  formSuccess.style.display = 'block';
});
